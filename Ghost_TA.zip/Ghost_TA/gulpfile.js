const gulp = require('gulp');
const postcss = require('gulp-postcss');
const tailwindcss = require('tailwindcss');
const rename = require('gulp-rename');

// Compile CSS with Tailwind
gulp.task('compile_tailwindcss', () => {
    return gulp
        .src('./assets/css/default.css')
        .pipe(
            postcss([
                tailwindcss({ config: './tailwind.config.js' }), 
                require('autoprefixer')
            ])
        )
        .pipe(rename('compiled.css'))
        .pipe(gulp.dest('./assets/css/'))
});

// Compile Tailwind with changes
gulp.task('watch_tailwindcss', () => {
    gulp.watch(
        [
            './**/*.hbs',
            './assets/css/default.css',
            './**/*.js',
        ],
        gulp.series('compile_tailwindcss')
    );
});
