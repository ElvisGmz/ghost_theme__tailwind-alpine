module.exports = {
  mode: 'jit',
  purge: [
    './**/*.hbs',
    './*.hbs',
  ],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
    },
  },
  variants: {
    extend: {
      // group-hover for scale
      scale: ['group-hover'],
    },
  },
  plugins: [],
}
